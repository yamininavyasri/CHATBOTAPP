
Navigate into the folder - cd NAVYA-CHAT-BOT
cd chatbot-app
Install the dependencies npm install
In index.js file, give the configuration details of organization group, apiKey of openAI account
Run the index.js file - node index
That will start the backend server on port 8000: http://localhost:8000/

Navigate into frontend folder - cd frontend
Install the dependencies npm install
Start the local server - npm run dev
This will start the chatbot application on port 3000: http://localhost:3000/

ChatBot Recording link:
https://drive.google.com/file/d/19LTBLD06YWdJFGfPwO3NuOXpTQTpPpsu/view?usp=sharing
